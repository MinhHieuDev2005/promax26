"""Idle multi-day beam benchmark using the existing validated runner protocol."""
import argparse
import copy
import json
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from run_snapshot import BENCH, ROOT


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--snapshot',type=Path,required=True)
    parser.add_argument('--exe',type=Path,required=True)
    parser.add_argument('--budget',type=int,default=3000)
    parser.add_argument('--beam',type=int,default=3)
    parser.add_argument('--candidates',type=int,default=4)
    parser.add_argument('--threads',type=int,default=2)
    parser.add_argument('--roles',default='0,0,0,0,1,0,0')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    source=json.loads(args.snapshot.read_text(encoding='utf-8'))
    roles=[int(x) for x in args.roles.split(',')]
    source['types']=roles
    for agent,kind in zip(source['day_info']['agents'],roles): agent['kind']=kind
    exe=args.exe.resolve()
    env=dict(os.environ,HEXUDON_THREADS=str(args.threads))
    beam=[{'data':source,'days':[],'traffic':[]}]

    def expand(item,seed):
        data=copy.deepcopy(item['data'])
        data['search']={'timeLimitMs':args.budget,'randomSeed':seed,'threads':args.threads,
            'futureWeight':0.0,'crossMoves':7,'endSpotWeight':0.0,
            'objectiveMode':'OFFICIAL_LEXICOGRAPHIC'}
        response,wall=BENCH.call(exe,data,env,timeout=args.budget/1000+15)
        replay=BENCH.trace(data,response['plan'],env)
        frame=replay['frames'][-1]
        day=data['day_info']['day']
        record={'day':day,'seed':seed,'wall_ms':wall,'score':[
            len(set(data['history']['distinct_brands'])|
                {s['brand'] for s in data['config']['spots']
                 if any(a['spot']==s['pos'] for a in replay['acquisitions'])}),
            len({s['brand'] for s in data['config']['spots']
                 if any(a['spot']==s['pos'] for a in replay['acquisitions'])}),
            frame['servings']], 'plan':response['plan'],
            'start_agents':copy.deepcopy(data['day_info']['agents']),
            'end_agents':copy.deepcopy(frame['agents'])}
        traffic=item['traffic'][:]
        BENCH.advance(data,response['plan'],replay,traffic)
        for road in data['day_info']['traffics']: road['status']=0
        return {'data':data,'days':item['days']+[record],'traffic':traffic}

    total_days=len(source['config']['daySteps'])
    for day in range(total_days):
        jobs=[]
        with ThreadPoolExecutor(max_workers=max(1,min(len(beam)*args.candidates,8))) as pool:
            for index,item in enumerate(beam):
                for candidate in range(args.candidates):
                    seed=1+day*1000+index*args.candidates+candidate
                    jobs.append(pool.submit(expand,item,seed))
            expanded=[job.result() for job in jobs]
        # Exact official requirements first. Keep position diversity so high-fuel
        # copies of the same boundary do not consume the whole beam.
        full=[x for x in expanded if x['days'][-1]['score'][:2]==[24,24]]
        if full: expanded=full
        unique={}
        for item in expanded:
            key=tuple((a['cell'],a['fuel']) for a in item['days'][-1]['end_agents'])
            total=item['data']['history']['total_servings']
            if key not in unique or total>unique[key]['data']['history']['total_servings']:
                unique[key]=item
        expanded=list(unique.values())
        expanded.sort(key=lambda x:(x['data']['history']['total_servings'],
            sum(a['fuel'] for a in x['days'][-1]['end_agents'] if a['type']==0)),reverse=True)
        # Reserve one lower-score/high-fuel state when available.
        selected=expanded[:args.beam]
        if len(expanded)>args.beam and args.beam>1:
            fuel=max(expanded[args.beam-1:],key=lambda x:sum(
                a['fuel'] for a in x['days'][-1]['end_agents'] if a['type']==0))
            selected[-1]=fuel
        beam=selected
        print('BEAM',day,[(x['data']['history']['total_servings'],
            sum(a['fuel'] for a in x['days'][-1]['end_agents'] if a['type']==0)) for x in beam])
    best=max(beam,key=lambda x:(len(x['data']['history']['distinct_brands']),
        x['data']['history']['cumulative_daily_types'],x['data']['history']['total_servings']))
    result={'score':[len(best['data']['history']['distinct_brands']),
        best['data']['history']['cumulative_daily_types'],best['data']['history']['total_servings']],
        'beam':args.beam,'candidates':args.candidates,'threads':args.threads,
        'budget_ms':args.budget,'exe':str(exe),'days':best['days']}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(result['score'])


if __name__=='__main__': main()
