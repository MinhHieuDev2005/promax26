#pragma once
#include "hexa_udon/solver.hpp"
namespace duc {
// Eliminate only closed detours with a full-plan dominance certificate.
// Equal duration preserves all later arrivals. Transit through empty spots is legal.
inline int remove_dominated_loops(std::vector<std::vector<int>>& plan,
    const std::vector<hexa_udon::solver::Agent>& start,
    const std::vector<int>& traffic, int steps, double budget) {
    namespace s = hexa_udon::solver;
    s::Timer timer;
    auto best = s::simulateDay(start,plan,traffic,steps);
    if (!best.valid) return 0;
    int saved = 0;
    for (size_t a=0; a<plan.size() && timer.ms()<budget; ++a) {
        if (start[a].kind!=0) continue;
        bool changed=true;
        while (changed && timer.ms()<budget) {
            changed=false;
            std::vector<int> cells{start[a].pos}, ticks{0};
            for (int action : plan[a]) {
                ticks.push_back(ticks.back()+(action<0 ? -action : s::stepCost(cells.back(),traffic)));
                cells.push_back(action<0 ? cells.back() : s::neighbor(cells.back(),action));
            }
            for (size_t left=0; left<plan[a].size() && !changed && timer.ms()<budget; ++left) {
                for (size_t right=left+2; right<cells.size() && timer.ms()<budget; ++right) {
                    if (cells[left]!=cells[right]) continue;
                    int movingTicks=0;
                    for (size_t k=left;k<right;++k)
                        if (plan[a][k]>=0) movingTicks+=ticks[k+1]-ticks[k];
                    if (!movingTicks) continue;
                    auto candidate=plan;
                    auto& route=candidate[a];
                    route.erase(route.begin()+left,route.begin()+right);
                    route.insert(route.begin()+left,-(ticks[right]-ticks[left]));
                    auto actual=s::simulateDay(start,candidate,traffic,steps);
                    if (!actual.valid || actual.brandHit!=best.brandHit || actual.balls<best.balls) continue;
                    bool dominates=true;
                    for (size_t i=0;i<start.size();++i)
                        if (actual.end[i].pos!=best.end[i].pos || actual.end[i].fuel<best.end[i].fuel) dominates=false;
                    if (!dominates) continue;
                    saved+=movingTicks;
                    plan=std::move(candidate);
                    best=std::move(actual);
                    changed=true;
                    break;
                }
            }
        }
    }
    return saved;
}
}
