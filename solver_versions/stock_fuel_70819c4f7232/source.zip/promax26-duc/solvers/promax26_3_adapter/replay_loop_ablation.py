"""Apply C++ loop repair to identical saved inputs/plans, with independent replay."""
import copy
import csv
import json
import os
from run_snapshot import BENCH, ROOT

def main():
    rows=[]
    for seed in (1,2,3):
        report=json.loads((ROOT/f'reports/stock-fuel/baseline-3000ms-s{seed}.json').read_text(encoding='utf-8'))
        data=json.loads((ROOT/'cases/master/32japan.snapshot.json').read_text(encoding='utf-8'))
        traffic=[]
        for day in report['days']:
            data['day_info']['agents']=day['start_agents']
            original=BENCH.trace(data,day['plan'],os.environ.copy())
            payload=copy.deepcopy(data)
            payload['replayPlan']=day['plan']
            payload['search']={'timeLimitMs':3000,'threads':1,'loopRepair':True}
            response,ms=BENCH.call(ROOT/'build-stock-fuel/udon_stock_fuel_runner.exe',payload,os.environ.copy())
            changed=BENCH.trace(data,response['plan'],os.environ.copy())
            a,b=original['frames'][-1],changed['frames'][-1]
            assert b['servings']>=a['servings']
            assert all(x['cell']==y['cell'] and x['fuel']<=y['fuel'] for x,y in zip(a['agents'],b['agents']))
            rows.append([seed,day['day'],a['servings'],b['servings'],
                response['diagnostics']['removed_loop_movement_ticks'],
                sum(y['fuel']-x['fuel'] for x,y in zip(a['agents'],b['agents'])),ms])
            # Use original boundary states to isolate the effect on this exact plan.
            BENCH.advance(data,day['plan'],original,traffic)
            for road in data['day_info']['traffics']: road['status']=0
    output=ROOT/'reports/stock-fuel/LOOP_REPLAY_RESULTS.csv'
    with output.open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f)
        writer.writerow(['seed','day','before_udon','after_udon','removed_movement_ticks','end_fuel_gain','runtime_ms'])
        writer.writerows(rows)
    print(json.dumps({'plans':len(rows),'removed_movement_ticks':sum(r[4] for r in rows),
        'end_fuel_gain':sum(r[5] for r in rows),'udon_gain':sum(r[3]-r[2] for r in rows)}))

if __name__=='__main__': main()
